

<?php $__env->startSection('title', 'Formato Compatibilidad'); ?>

<?php $__env->startSection('content'); ?>
    
<div class="row">
  <div class="col">
    <br>
    <br>
    <h1>Proceso Transcurrido</h1>
    <h4>Tiempo Transcurrido</h4>
    <hr class="red" style="margin: 0%;">
  </div>
</div>

<br>
<div class="row">
  <div class="col-sm-5">

    <table class="table text-center table-responsive">
      <thead>
        <tr>
          <th class="text-center">Plantel</th>
          <th class="text-center">Area Auxiliar</th>
          <th class="text-center">DGETI</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
          <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
          </td>
          <td>
          <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
          </td>
          <td>
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true" style="color:#DDDDDD;"></span>
          </td>
        </tr>
        <tr>
          <td>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
          </td>
          <td>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
          </td>
          <td>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true" style="color:#DDDDDD;"></span>
          </td>
        </tr>
      </tbody>

    </table>

  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_CNAD\resources\views/compatibilidad/estatusTramitePersonal.blade.php ENDPATH**/ ?>